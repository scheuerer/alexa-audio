OH Weather 0.5.9 (Quellcode)
- Cloud-Modus aus 0.5.8 bleibt erhalten
- Sitemap-Auswahl direkt in den Haupteinstellungen
- Sitemap-Bearbeitung, Export und REST bleiben vorerst im bestehenden Editor, erreichbar aus den Haupteinstellungen
- Favoriten-Pfeile und Hinzufuegen/Entfernen visuell verbessert
- Mehr Abstand am unteren Rand des Sitemap-Editors
- Bestehende Android-Auto-Diagrammlogik unveraendert
Hinweis: Vollstaendige Integration aller Sitemap-Editorfunktionen in die Hauptseite ist noch nicht umgesetzt.
Nicht auf Android gebaut oder getestet. Gradle Wrapper muss aus dem bestehenden Projekt uebernommen werden.
