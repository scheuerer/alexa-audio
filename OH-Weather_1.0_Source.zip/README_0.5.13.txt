OH Weather 0.5.13
- Central version from BuildConfig.VERSION_NAME for settings and Android Auto header.
- Adaptive launcher foreground transparent and inset for host masking; blue background retained.
- Six favorites and weather functionality unchanged.
- Android Auto host may still draw its own icon surround.
