OH Weather 0.4 - PROD WS90 Livewerte

Neue Defaults aus der REST-Itemliste vom PROD-System (1770 Items).
Alte 0.3-Platzhalter werden migriert, individuell geaenderte Item-Zuordnungen bleiben erhalten.
Regenstatus (ON/OFF) und Regenmenge 1h (mm) sind getrennt.
Surface und Pane zeigen keine erfundenen Demowerte mehr; Aktualisierung alle 60 Sekunden.
Sitemap-Editor aus 0.3 bleibt erhalten.
WICHTIG: Nicht lokal Android-kompiliert; bitte auf Windows mit Gradle testen.
