OH Weather 0.5.15
- Version centralized in Gradle BuildConfig.VERSION_NAME; displayed in settings and Car App header.
- German/English UI selector and translated favorite editor controls.
- Insets-aware bottom padding for gesture/navigation bars.
- Preserves six favorites, history and sitemap editor.
- Android Auto may apply its own white icon frame; host rendering cannot be overridden by the app.
- Build not verified in this environment.
