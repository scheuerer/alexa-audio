OH Weather 0.5.12
- Settings version label derives from Android package versionName.
- Launcher icon backgrounds are solid blue, including legacy and adaptive foreground PNGs.
- Android Auto may impose its own icon background or frame.
- Six favorites and all other functionality unchanged.
