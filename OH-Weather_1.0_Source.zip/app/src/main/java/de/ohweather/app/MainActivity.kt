package de.ohweather.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*
import java.util.concurrent.Executors

class MainActivity:Activity() {
    private fun tr(de:String,en:String)=if(WeatherConfig.get(this,"ui_language","de")=="en") en else de
    private val bg=Color.rgb(15,23,42)
    private val fieldBg=Color.rgb(51,65,85)
    private val blue=Color.rgb(59,130,246)
    private val muted=Color.rgb(165,178,197)
    private lateinit var root:LinearLayout
    private lateinit var status:TextView
    private val fields=linkedMapOf<String,EditText>()
    private val pool=Executors.newSingleThreadExecutor()
    private var favs=mutableListOf<WeatherConfig.Favorite>()
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun shape(color:Int)=GradientDrawable().apply { setColor(color);cornerRadius=dp(12).toFloat() }
    private fun text(t:String,size:Float=15f,color:Int=Color.WHITE)=TextView(this).apply { text=t;textSize=size;setTextColor(color);setPadding(0,dp(8),0,dp(8)) }
    private fun heading(t:String){root.addView(text(t,21f).apply{setPadding(0,dp(22),0,dp(8))})}
    private fun field(key:String,title:String,default:String,password:Boolean=false):EditText {
        root.addView(text(title,14f,muted))
        val e=EditText(this).apply { setSingleLine(true);setText(WeatherConfig.get(this@MainActivity,key,default));textSize=16f;setTextColor(Color.WHITE);background=shape(fieldBg);setPadding(dp(12),dp(12),dp(12),dp(12));if(password)inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD }
        root.addView(e,LinearLayout.LayoutParams(-1,dp(55)).apply{bottomMargin=dp(7)})
        fields[key]=e;return e
    }
    private fun button(label:String,action:()->Unit) {
        root.addView(Button(this).apply{text=label;isAllCaps=false;setTextColor(Color.WHITE);background=shape(blue);setOnClickListener{action()}},LinearLayout.LayoutParams(-1,dp(49)).apply{topMargin=dp(8)})
    }
    private fun whiteSpinnerAdapter(values:Array<String>):ArrayAdapter<String> = object:ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values) {
        override fun getView(position:Int,convertView:View?,parent:ViewGroup):View = super.getView(position,convertView,parent).also { (it as? TextView)?.setTextColor(Color.WHITE) }
        override fun getDropDownView(position:Int,convertView:View?,parent:ViewGroup):View = super.getDropDownView(position,convertView,parent).also { (it as? TextView)?.setTextColor(Color.WHITE);it.setBackgroundColor(fieldBg) }
    }
    private fun choose(items:Array<String>, selected:Int, action:(Int)->Unit) {
        AlertDialog.Builder(this).setSingleChoiceItems(items,selected){d,n->d.dismiss();action(n)}.setNegativeButton(tr("Abbrechen","Cancel"),null).show()
    }
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState);WeatherConfig.migrate(this);favs=WeatherConfig.favorites(this).toMutableList();draw() }
    private fun draw() {
        fields.clear()
        val scroll=ScrollView(this).apply{setBackgroundColor(bg);clipToPadding=false}
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(15),dp(18),dp(28))}
        scroll.addView(root);setContentView(scroll)
        // Respect Android gesture/navigation bars without placing controls underneath them.
        scroll.setOnApplyWindowInsetsListener { view, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars())
            view.setPadding(0, 0, 0, bars.bottom)
            insets
        }
        window.statusBarColor=bg;window.navigationBarColor=bg
        heading("OH Weather ${BuildConfig.VERSION_NAME} · ${tr("Einstellungen","Settings")}")
        heading(tr("Sprache / Language","Language / Sprache"))
        val language=Spinner(this).apply { background=shape(fieldBg);adapter=whiteSpinnerAdapter(arrayOf("Deutsch","English"));setSelection(if(WeatherConfig.get(this@MainActivity,"ui_language","de")=="en")1 else 0) }
        root.addView(language,LinearLayout.LayoutParams(-1,dp(55)))
        button(tr("Sprache übernehmen","Apply language")) {
            val lang=if(language.selectedItemPosition==1)"en" else "de"
            WeatherConfig.prefs(this).edit().putString("ui_language",lang).apply()
            draw()
        }
        heading(tr("Verbindung","Connection"))
        val modes=arrayOf(tr("Lokal / VPN","Local / VPN"),"myopenHAB Cloud")
        val mode=Spinner(this)
        val modeAdapter=whiteSpinnerAdapter(modes)
        mode.background=shape(fieldBg)
        mode.adapter=modeAdapter
        mode.setSelection(0)
        mode.setSelection(if(WeatherConfig.get(this,"mode","local")=="cloud")1 else 0)
        root.addView(mode,LinearLayout.LayoutParams(-1,dp(55)))
        val local=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val cloud=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        // Fields are added to the root and visibility controlled by section ranges.
        val localStart=root.childCount
        field("host",tr("Lokaler Server","Local server"),"http://192.168.1.9")
        field("port","Port","8080")
        val localEnd=root.childCount
        field("cloud","Cloud-URL","https://myopenhab.org")
        val cloudStart=localEnd;val cloudEnd=root.childCount
        heading(tr("Anmeldung","Authentication"))
        val token=EditText(this).apply{setSingleLine(true);setText(WeatherTokenStore.read(this@MainActivity));setTextColor(Color.WHITE);background=shape(fieldBg);setPadding(dp(12),dp(10),dp(12),dp(10));inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
        root.addView(text(tr("API-Token (bevorzugt)","API token (preferred)"),14f,muted));root.addView(token,LinearLayout.LayoutParams(-1,dp(54)))
        button(tr("Token anzeigen / verbergen","Show / hide token")) {val pos=token.selectionStart;token.inputType=if(token.inputType and InputType.TYPE_TEXT_VARIATION_PASSWORD !=0)InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;token.setSelection(pos.coerceIn(0,token.length()))}
        val authStart=root.childCount
        field("user",tr("Cloud-E-Mail (alternativ)","Cloud email (alternative)"),"")
        field("secret",tr("Cloud-Passwort (alternativ)","Cloud password (alternative)"),"",true)
        val authEnd=root.childCount
        fun showMode(){val isCloud=mode.selectedItemPosition==1;for(i in localStart until localEnd)root.getChildAt(i).visibility=if(isCloud)View.GONE else View.VISIBLE;for(i in cloudStart until cloudEnd)root.getChildAt(i).visibility=if(isCloud)View.VISIBLE else View.GONE;for(i in authStart until authEnd)root.getChildAt(i).visibility=if(isCloud)View.VISIBLE else View.GONE}
        mode.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:android.widget.AdapterView<*>?){};override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){showMode()}}
        fun saveConnection(){WeatherTokenStore.write(this,token.text.toString().trim());val e=WeatherConfig.prefs(this).edit().putString("mode",if(mode.selectedItemPosition==1)"cloud" else "local").putString("auth_mode",if(token.text.isNotBlank())"token" else if(fields["user"]?.text?.isNotBlank()==true)"password" else "anonymous");fields.forEach{(k,v)->e.putString(k,v.text.toString().trim())};e.apply()}
        heading(tr("Sitemap und Daten","Sitemap and data"))
        field("sitemap",tr("Sitemap-Name (optional)","Sitemap name (optional)"),"ohweather")
        button(tr("Sitemap auswählen (Datei / REST)","Select sitemap (file / REST)")) {
            saveConnection()
            async {
                val sites=WeatherConfig.sitemapNames(this)
                runOnUiThread {
                    if(sites.isEmpty()) status.text=tr("Keine Sitemaps gefunden","No sitemaps found")
                    else choose(sites.toTypedArray(),sites.indexOf(fields["sitemap"]?.text?.toString())) { n ->
                        fields["sitemap"]?.setText(sites[n]);status.text=tr("Ausgewählt: ${sites[n]} – bitte Einstellungen speichern","Selected: ${sites[n]} – please save settings")
                    }
                }
                tr("${sites.size} Sitemaps gefunden","${sites.size} sitemaps found")
            }
        }
        root.addView(text(tr("Sitemap-Einträge, Icon-Auswahl (Classic/F7), Bedienungsarten und Positionen bearbeiten sowie Export, REST-Speicherung und Verwerfen bleiben verfügbar.","Edit sitemap entries, Classic/F7 icons, control types and positions; export, REST saving and discard remain available."),13f,muted))
        button(tr("Sitemap bearbeiten · Export · REST","Edit sitemap · Export · REST")) {saveConnection();WeatherConfig.saveFavorites(this,favs);startActivity(Intent(this,SitemapEditorActivity::class.java))}
        heading(tr("Favoriten · 1 bis 6","Favorites · 1 to 6"))
        root.addView(text(tr("Antippen: Item, Bezeichnung, Einheit und Diagrammtyp bearbeiten. Mit den Pfeilen Reihenfolge ändern.","Tap to edit item, label, unit and chart type. Use arrows to reorder."),14f,muted))
        val favContainer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        root.addView(favContainer)
        fun redrawFavorites() {
            favContainer.removeAllViews()
            favs.forEachIndexed { index,f ->
                val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(7),dp(5),dp(7),dp(5));background=shape(fieldBg)}
                val label=text("${index+1}. ${f.label}  ·  ${f.type.uppercase()}\n${f.item}",14f).apply{maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setOnClickListener{editFavorite(index){redrawFavorites()}}}
                row.addView(label,LinearLayout.LayoutParams(0,dp(66),1f))
                for((symbol,delta) in listOf("↑" to -1,"↓" to 1)) {
                    row.addView(Button(this).apply{text=symbol;isAllCaps=false;textSize=22f;setTextColor(Color.WHITE);background=shape(Color.rgb(30,64,135));setOnClickListener{val j=index+delta;if(j in favs.indices){java.util.Collections.swap(favs,index,j);redrawFavorites()}}},LinearLayout.LayoutParams(dp(42),dp(60)).apply { marginStart=dp(5) })
                }
                favContainer.addView(row,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})
            }
        }
        fun changeCount(delta:Int) {
            val next=favs.size+delta
            if(next !in 1..6) return
            if(delta>0) favs.add(WeatherConfig.Favorite(tr("Favorit $next","Favorite $next"), "", "line", "")) else favs.removeAt(favs.lastIndex)
            redrawFavorites()
        }
        val countControls=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        countControls.addView(Button(this).apply {text=tr("− Favorit","− Favorite");isAllCaps=false;setTextColor(Color.WHITE);background=shape(blue);setOnClickListener{changeCount(-1)}},LinearLayout.LayoutParams(0,dp(50),1f).apply { marginEnd=dp(5);topMargin=dp(9) })
        countControls.addView(Button(this).apply {text=tr("+ Favorit","+ Favorite");isAllCaps=false;setTextColor(Color.WHITE);background=shape(blue);setOnClickListener{changeCount(1)}},LinearLayout.LayoutParams(0,dp(50),1f).apply { marginStart=dp(5);topMargin=dp(9) })
        root.addView(countControls)
        redrawFavorites()
        button(tr("Verbindung prüfen","Test connection")) {saveConnection();async {WeatherConfig.request(this,"/rest/items?recursive=false");tr("Verbindung erfolgreich","Connection successful")}}
        button(tr("Einstellungen und Favoriten speichern","Save settings and favorites")) {saveConnection();WeatherConfig.saveFavorites(this,favs);status.text=tr("Gespeichert. Android Auto neu öffnen.","Saved. Reopen Android Auto.")}
        status=text("",14f);root.addView(status)
        root.addView(text(tr("24-Stunden-Verläufe aus RRD4J. ON/OFF wird als Zustandsverlauf angezeigt. Regenmenge in l/m².","24-hour charts from RRD4J. ON/OFF values appear as state timelines. Rainfall in l/m²."),13f,muted))
        showMode()
    }
    private fun editFavorite(index:Int,done:()->Unit) {
        val f=favs[index]
        val layout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),0)}
        fun edit(label:String,value:String):EditText {layout.addView(text(label,13f,muted));return EditText(this).apply{setText(value);setTextColor(Color.WHITE);setSingleLine(true);background=shape(fieldBg);setPadding(dp(10),dp(8),dp(10),dp(8));layout.addView(this)}}
        val name=edit(tr("Anzeigename","Display name"),f.label)
        val item=edit(tr("openHAB Item-Name","openHAB item name"),f.item)
        val search=Button(this).apply{text=tr("Item suchen","Search item");setOnClickListener{
            val term=EditText(this@MainActivity).apply{setText(name.text.toString());setSingleLine(true)}
            AlertDialog.Builder(this@MainActivity).setTitle(tr("Volltextsuche","Full-text search")).setView(term).setPositiveButton(tr("Suchen","Search")){_,_->async {
                val names=WeatherConfig.itemNames(this@MainActivity,term.text.toString())
                runOnUiThread {AlertDialog.Builder(this@MainActivity).setTitle(tr("Item auswählen","Select item")).setItems(names.toTypedArray()){_,n->item.setText(names[n])}.setNegativeButton(tr("Abbrechen","Cancel"),null).show()};"${names.size} Items gefunden"
            }}.setNegativeButton(tr("Abbrechen","Cancel"),null).show()
        }};layout.addView(search)
        val types=arrayOf(tr("Linie","Line"),tr("Balken","Bar"),tr("Zustand ON/OFF","ON/OFF state"))
        val type=Spinner(this).apply{setBackgroundColor(fieldBg);adapter=whiteSpinnerAdapter(types);setSelection(listOf("line","bar","state").indexOf(f.type).coerceAtLeast(0))};layout.addView(type)
        val unit=edit(tr("Einheit (z.B. °C, %, km/h, l/m²)","Unit (e.g. °C, %, km/h, l/m²)"),f.unit)
        AlertDialog.Builder(this).setTitle(tr("Favorit ${index+1}","Favorite ${index+1}")).setView(layout).setPositiveButton(tr("Übernehmen","Apply")){_,_->
            favs[index]=WeatherConfig.Favorite(name.text.toString().ifBlank{tr("Favorit ${index+1}","Favorite ${index+1}")},item.text.toString().trim(),listOf("line","bar","state")[type.selectedItemPosition],unit.text.toString().trim());done()
        }.setNegativeButton(tr("Abbrechen","Cancel"),null).show()
    }
    private fun async(task:()->String){status.text=tr("Bitte warten ...","Please wait ...");pool.execute{val result=try{task()}catch(e:Exception){tr("Fehler: ${e.message}","Error: ${e.message}")};runOnUiThread{status.text=result}}}
    override fun onDestroy(){pool.shutdownNow();super.onDestroy()}
}
