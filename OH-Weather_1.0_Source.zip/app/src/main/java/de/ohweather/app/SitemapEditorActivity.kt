package de.ohweather.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Environment
import android.content.ContentValues
import android.provider.MediaStore
import android.text.InputType
import android.graphics.Color
import android.graphics.drawable.PictureDrawable
import com.caverock.androidsvg.SVG
import android.text.TextWatcher
import android.text.Editable
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.view.Gravity
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.GridLayout
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import kotlin.concurrent.thread

/** OH Weather: creates a REST-managed copy when editing a file-based sitemap. */
class SitemapEditorActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var info: TextView
    private lateinit var query: EditText
    private lateinit var results: LinearLayout
    private lateinit var entries: LinearLayout
    private lateinit var labelInput: EditText
    private lateinit var iconInput: EditText
    private lateinit var flags: Spinner
    private lateinit var position: EditText
    private var definition: JSONObject? = null
    private var pending: JSONArray = JSONArray()
    private var selected: JSONObject? = null
    private var loadedSite = ""
    private var sourceFileBased = false
    private val classicSuggestions = listOf("humidity", "temperature", "rain", "wind", "sun", "light", "poweroutlet", "switch", "door", "garage", "garagedoor", "rollershutter", "lawnmower", "vacation", "house", "water", "battery", "energy", "heating", "fan")
    private val f7Icons by lazy { assets.list("f7")?.filter { it.endsWith(".svg") }?.map { it.removeSuffix(".svg") }?.sorted() ?: emptyList() }
    private val prefs by lazy { WeatherConfig.prefs(this) }

    private val background = Color.rgb(15, 23, 42)
    private val cardColor = Color.rgb(30, 41, 59)
    private val fieldColor = Color.rgb(51, 65, 85)
    private val muted = Color.rgb(148, 163, 184)
    private val blue = Color.rgb(59, 130, 246)
    private fun tr(de: String, en: String) = if (WeatherConfig.get(this,"ui_language","de") != "en") de else en
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 12) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun input(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint
        setText(value)
        setSingleLine(true)
        textSize = 16f
        setTextColor(Color.WHITE)
        setHintTextColor(muted)
        background = rounded(fieldColor)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }
    private fun button(title: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = title
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(blue)
            minHeight = dp(50)
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
    }
    private fun label(value: String, heading: Boolean = false) {
        root.addView(TextView(this).apply {
            text = value
            textSize = if (heading) 20f else 14f
            setTextColor(if (heading) Color.WHITE else muted)
            if (heading) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(12))
        })
    }
    private fun message(value: String) { runOnUiThread { info.text = value } }
    private fun site() = prefs.getString("sitemap", "ohweather_live") ?: "ohweather_live"
    private fun endpoint(path: String): String = "${WeatherConfig.base(this)}/rest/$path"
    private fun request(path: String, method: String = "GET", body: String? = null): Pair<Int, String> {
        val c = URL(endpoint(path)).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("Accept", "application/json")
            WeatherConfig.authorize(this, c)
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            return code to text
        } finally { c.disconnect() }
    }
    private fun background(action: () -> Unit) = thread {
        try { action() } catch (e: Exception) { message(tr("Fehler: ${e.message}", "Error: ${e.message}")) }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(38), dp(20), dp(110))
            setBackgroundColor(this@SitemapEditorActivity.background)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        window.statusBarColor = background
        window.navigationBarColor = background
        label(tr("OH Weather – Sitemap-Editor", "OH Weather – Sitemap Editor"), true)
        label(tr("DATEI: Export speichert eine .sitemap-Datei in Downloads. Diese muss manuell nach /etc/openhab/sitemaps/ kopiert werden. REST: Speichert eine getrennte Sitemap namens ohweather_live in openHAB. Die ursprüngliche Datei bleibt unverändert. Welche Sitemap OH Weather nutzt, wählst du selbst.", "FILE: Export saves a .sitemap file to Downloads. Copy it manually to /etc/openhab/sitemaps/. REST: Saves a separate sitemap named ohweather_live in openHAB. The original file remains unchanged. You choose which sitemap OH Weather uses."))
        info = TextView(this).apply {
            text = tr("Zum Start Sitemap laden", "Load sitemap to begin")
            textSize = 14f
            setTextColor(Color.WHITE)
            background = rounded(cardColor)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            root.addView(this, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }
        button(tr("Sitemaps auswählen", "Choose sitemap")) { chooseSitemap() }
        button(tr("Sitemap laden", "Load sitemap")) { load() }
        // Show the loaded sitemap immediately after the load action.
        // Keep this list here so users see its contents before the item search.
        label(tr("Sitemap-Einträge (tippen: bearbeiten; lange drücken: entfernen)", "Sitemap entries (tap to edit; long-press to remove)"))
        entries = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; root.addView(this) }
        query = input(tr("Items nach Name oder Bezeichnung suchen", "Search items by name or label"))
        button(tr("Items suchen", "Search items")) { search() }
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; root.addView(this) }
        labelInput = input(tr("Anzeigename (optional)", "Display label (optional)"))
        iconInput = input(tr("Icon (aus Item-Kategorie, änderbar)", "Icon (from item category, editable)"))
        label(tr("Bedienungsart", "Tile mode"))
        label(tr("Anzeige und Reihenfolge", "Display and Order"))
        val modes = arrayOf(tr("Text / Status", "Text / status"), tr("Schalter / Umschalten", "Switch / toggle"), tr("Schalter / Live-Impuls", "Switch / impulse live"), tr("Regler / Rollladen", "Slider / rollershutter"), tr("0 % → 100 %", "0% → 100%"), tr("100 % → 0 %", "100% → 0%"))
        val modeAdapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, modes) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                super.getView(position, convertView, parent).also { view ->
                    (view as? TextView)?.apply {
                        setTextColor(Color.WHITE)
                        textSize = 16f
                        setPadding(dp(16), dp(14), dp(16), dp(14))
                    }
                }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                super.getDropDownView(position, convertView, parent).also { view ->
                    (view as? TextView)?.apply {
                        setTextColor(Color.WHITE)
                        setBackgroundColor(fieldColor)
                        textSize = 16f
                        setPadding(dp(16), dp(16), dp(16), dp(16))
                    }
                }
        }
        flags = Spinner(this).apply {
            adapter = modeAdapter
            background = rounded(fieldColor, 14)
            minimumHeight = dp(56)
            root.addView(this, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(16) })
        }
        label(tr("WEITERE KACHEL HINZUFÜGEN", "ADD ANOTHER TILE"), true)
        label(tr("Die folgende Position ist nur der Vorschlag für die NÄCHSTE neue Kachel. Bereits übernommene Kacheln stehen oben in der Liste und behalten ihre Position.", "The position below is only the suggestion for the NEXT new tile. Tiles already applied are shown in the list above and keep their position."))
        position = input(tr("Position der nächsten neuen Kachel", "Position of next new tile"), "1").apply { inputType = InputType.TYPE_CLASS_NUMBER }
        button(tr("Kachel konfigurieren / einfügen", "Configure / insert tile")) { configureSelected() }
        button(tr("Als .sitemap in Downloads exportieren", "Export .sitemap to Downloads")) { exportSitemap() }
        button(tr("Änderungen in openHAB speichern (REST)", "Save changes to openHAB (REST)")) { save() }
        button(tr("Änderungen verwerfen / neu laden", "Discard changes / reload")) { load() }
    }
    private fun chooseSitemap() = background {
        val (code, data) = request("sitemaps")
        if (code != 200) { message(tr("Sitemap-Liste fehlgeschlagen: HTTP $code", "Sitemap list failed: HTTP $code")); return@background }
        val arr = JSONArray(data)
        val names = (0 until arr.length()).mapNotNull { index ->
            val obj = arr.optJSONObject(index)
            (obj?.optString("name") ?: arr.optString(index)).takeIf { it.isNotBlank() }
        }.distinct().sorted()
        runOnUiThread {
            if (names.isEmpty()) { message(tr("Keine Sitemaps gefunden", "No sitemaps found")); return@runOnUiThread }
            AlertDialog.Builder(this)
                .setTitle(tr("Sitemap auswählen", "Choose sitemap"))
                .setSingleChoiceItems(names.toTypedArray(), names.indexOf(site())) { dialog, which ->
                    val chosen = names[which]
                    if (prefs.edit().putString("sitemap", chosen).commit()) {
                        dialog.dismiss()
                        load()
                    } else message(tr("Auswahl konnte nicht gespeichert werden", "Could not save selection"))
                }
                .setNegativeButton(tr("Abbrechen", "Cancel"), null)
                .show().also { dialog ->
                    styleDialog(dialog)
                    dialog.listView?.apply {
                        setBackgroundColor(cardColor)
                        for (i in 0 until childCount) (getChildAt(i) as? TextView)?.setTextColor(Color.WHITE)
                        setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                            override fun onChildViewAdded(parent: View?, child: View?) { (child as? TextView)?.setTextColor(Color.WHITE) }
                            override fun onChildViewRemoved(parent: View?, child: View?) {}
                        })
                    }
                }
        }
    }
    private fun load() = background {
        val current = site()
        val (code, data) = request("sitemaps/$current/definition")
        if (code != 200) { message(tr("Laden fehlgeschlagen: HTTP $code", "Load failed: HTTP $code")); return@background }
        val parsed = JSONObject(data)
        val fileBased = !parsed.optBoolean("editable", false)
        val arr = parsed.optJSONArray("widgets") ?: JSONArray()
        val copy = JSONArray(arr.toString())
        runOnUiThread {
            definition = parsed
            pending = copy
            loadedSite = current
            sourceFileBased = fileBased
            message(if (fileBased) tr("Quelle: Datei-Sitemap $current. REST-Speichern aktualisiert diese Datei NICHT.", "Source: file sitemap $current. REST saving does NOT update this file.") else tr("Quelle: REST-Sitemap $current (${copy.length()} Einträge)", "Source: REST sitemap $current (${copy.length()} entries)"))
            redraw()
        }
    }
    private fun search() {
        val term = query.text.toString().trim()
        background {
        if (term.length < 2) { message(tr("Mindestens zwei Zeichen eingeben", "Enter at least two characters")); return@background }
        val (code, data) = request("items?recursive=false")
        if (code != 200) { message(tr("Item-Suche fehlgeschlagen: HTTP $code", "Item search failed: HTTP $code")); return@background }
        val items = JSONArray(data)
        val matches = (0 until items.length()).map { items.getJSONObject(it) }
            .filter { matchesMeasurement(it, term) }
            .take(100)
        runOnUiThread {
            results.removeAllViews()
            matches.forEach { item ->
                results.addView(Button(this).apply {
                    isAllCaps = false
                    setTextColor(Color.WHITE)
                    background = rounded(fieldColor)
                    text = "${item.optString("label")} (${item.optString("name")})"
                    setOnClickListener {
                        selected = item
                        labelInput.setText(item.optString("label", item.optString("name")))
                        iconInput.setText(item.optString("category", ""))
                        flags.setSelection(if (item.optString("type") == "Rollershutter") 3 else if (item.optString("type") == "Switch") 1 else 0)
                        message(tr("Ausgewählt: ${item.optString("name")}", "Selected: ${item.optString("name")}"))
                        configureSelected()
                    }
                })
            }
            if (matches.isEmpty()) message(tr("Keine passenden Items", "No matching items"))
        }
        }
    }
    // Search for the measured property, not the name of the Thing embedded in the Item prefix.
    // Examples: LuftqualitaetsStation_Aussentemperatur must not match Luftfeuchtigkeit.
    private fun matchesMeasurement(item: JSONObject, raw: String): Boolean {
        val term = raw.trim().lowercase()
        val name = item.optString("name")
        val segments = name.split('_').filter { it.isNotBlank() }
        val measurement = segments.lastOrNull()?.lowercase() ?: return false
        val aliases = when {
            term.startsWith("luftfeucht") || term == "luft" || term == "feuchte" -> listOf("luftfeucht", "humidity", "feuchte", "relativehumidity")
            term.startsWith("temperatur") -> listOf("temperatur", "temperature")
            term.startsWith("windgeschwindigkeit") -> listOf("windgeschwindigkeit", "windspeed")
            else -> listOf(term)
        }
        // Match human-readable labels and full technical names as well as the last segment.
        val label = item.optString("label").lowercase()
        val fullName = name.lowercase()
        return aliases.any { alias -> measurement.contains(alias) || label.contains(alias) || fullName.contains(alias) }
    }
    private fun configureSelected() {
        val item = selected ?: run {
            val typed = query.text.toString().trim()
            if (typed.isEmpty()) { message(tr("Zuerst ein Item suchen oder auswählen", "Search or select an item first")); return }
            JSONObject().put("name", typed).put("label", labelInput.text.toString().trim().ifEmpty { typed }).put("category", iconInput.text.toString().trim())
        }
        showTileDialog(item, null)
    }
    private fun showTileDialog(item: JSONObject, editIndex: Int?) {
        if (definition == null) { message(tr("Zuerst bearbeitbare Sitemap laden", "Load an editable sitemap first")); return }
        val old = editIndex?.let { pending.getJSONObject(it) }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)); setBackgroundColor(cardColor) }
        fun field(title: String, value: String): EditText {
            box.addView(TextView(this).apply { text = title; setTextColor(muted); setPadding(0, dp(10), 0, dp(3)) })
            return EditText(this).apply {
                setText(value); setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted)
                background = rounded(fieldColor); setPadding(dp(12), dp(10), dp(12), dp(10))
                box.addView(this)
            }
        }
        val name = item.optString("name")
        val display = field(tr("Anzeigename", "Display name"), old?.optString("label")?.replace(Regex(""" \[ohdrive:[^]]+\]"""), "")?.replace(" [%s]", "") ?: item.optString("label", name))
        val iconField = field(tr("Icon (änderbar)", "Icon (editable)"), old?.optString("icon") ?: item.optString("category", ""))
        val chooseIcon = Button(this).apply {
            text = tr("Icon-Bibliothek öffnen", "Open icon library")
            isAllCaps = false; setTextColor(Color.WHITE); background = rounded(blue)
        }
        chooseIcon.setOnClickListener { showIconPicker(iconField) }
        box.addView(chooseIcon)
        box.addView(TextView(this).apply { text = tr("Bedienungsart", "Tile mode"); setTextColor(muted) })
        val choices = arrayOf(tr("Text / Status", "Text / status"), tr("Schalter / Umschalten", "Switch / toggle"), tr("Schalter / Live-Impuls", "Switch / live impulse"), tr("Regler / Rollladen", "Slider / rollershutter"), tr("0 % → 100 %", "0% → 100%"), tr("100 % → 0 %", "100% → 0%"))
        val mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@SitemapEditorActivity, android.R.layout.simple_spinner_dropdown_item, choices)
            setBackgroundColor(fieldColor); box.addView(this)
        }
        mode.setSelection(when {
            old?.optString("label")?.contains("ohdrive:impuls:live") == true -> 2
            old?.optString("label")?.contains("ohdrive:markise:100offen") == true || old?.optString("label")?.contains("ohdrive:rollo:100offen") == true -> 5
            old?.optString("label")?.contains("ohdrive:markise:0offen") == true || old?.optString("label")?.contains("ohdrive:rollo:0offen") == true -> 4
            old?.optString("type") == "Slider" || item.optString("type") == "Rollershutter" -> 3
            old?.optString("type") == "Switch" || item.optString("type") == "Switch" -> 1
            else -> 0
        })
        val currentPosition = (editIndex?.plus(1) ?: position.text.toString().toIntOrNull()?.coerceIn(1, pending.length() + 1) ?: (pending.length() + 1))
        box.addView(TextView(this).apply {
            text = if (editIndex == null) tr("Position dieser neuen Kachel: $currentPosition", "Position of this new tile: $currentPosition")
                   else tr("Aktuelle Position dieser Kachel: $currentPosition", "Current position of this tile: $currentPosition")
            setTextColor(Color.WHITE); textSize = 17f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, dp(14), 0, dp(6))
        })
        val order = field(tr("Position dieser Kachel (änderbar)", "Position of this tile (editable)"), currentPosition.toString())
        box.addView(TextView(this).apply {
            text = tr("Nach dem Übernehmen zeigt das Hauptformular automatisch die nächste freie Position an. Diese gehört nicht mehr zu dieser Kachel.", "After applying, the main form automatically shows the next available position. It does not belong to this tile.")
            setTextColor(muted); textSize = 13f; setPadding(0, dp(8), 0, dp(6))
        })
        order.inputType = InputType.TYPE_CLASS_NUMBER
        val scroll = ScrollView(this).apply { addView(box) }
        AlertDialog.Builder(this).setTitle(if (editIndex == null) tr("Neue Kachel", "New tile") else tr("Kachel bearbeiten", "Edit tile"))
            .setView(scroll)
            .setNegativeButton(tr("Abbrechen", "Cancel"), null)
            .setPositiveButton(tr("Übernehmen", "Apply")) { _, _ ->
                val rawLabel = display.text.toString().trim().ifEmpty { name }.replace(Regex(""" \[ohdrive:[^]]+\]"""), "").removeSuffix(" [%s]")
                val m = mode.selectedItemPosition
                val suffix = when (m) { 2 -> " [ohdrive:impuls:live]"; 4 -> " [ohdrive:markise:0offen] [%s]"; 5 -> " [ohdrive:markise:100offen] [%s]"; else -> "" }
                val widget = JSONObject(old?.toString() ?: "{}").put("item", name)
                    .put("type", if (m == 0) "Text" else if (m >= 3) "Slider" else "Switch")
                    .put("label", rawLabel + suffix)
                val ico = iconField.text.toString().trim()
                if (ico.isNotEmpty()) widget.put("icon", ico) else widget.remove("icon")
                if (m == 2) widget.put("mappings", JSONArray().put(JSONObject().put("command", "ON").put("label", "Impuls")))
                else if (editIndex == null || old?.optString("type") != widget.optString("type")) widget.remove("mappings")
                if (editIndex == null && (0 until pending.length()).any { pending.getJSONObject(it).optString("item") == name }) {
                    message(tr("Item bereits vorhanden. Vorhandene Kachel bearbeiten.", "Item already exists. Edit the existing tile."))
                } else {
                    val next = JSONArray()
                    for (i in 0 until pending.length()) if (i != editIndex) next.put(pending.getJSONObject(i))
                    val at = ((order.text.toString().toIntOrNull() ?: next.length() + 1) - 1).coerceIn(0, next.length())
                    val inserted = JSONArray()
                    for (i in 0..next.length()) { if (i == at) inserted.put(widget); if (i < next.length()) inserted.put(next.getJSONObject(i)) }
                    pending = inserted; redraw()
                    results.removeAllViews() // Collapse search results after a tile is successfully applied.
                    message(tr("Kachel übernommen (noch nicht gespeichert)", "Tile applied (not yet saved)"))
                }
            }.show().also { styleDialog(it) }
    }
    private fun styleDialog(dialog: AlertDialog) {
        dialog.window?.setBackgroundDrawable(rounded(cardColor, 16))
        dialog.findViewById<TextView>(resources.getIdentifier("alertTitle", "id", "android"))?.setTextColor(Color.WHITE)
        dialog.findViewById<TextView>(android.R.id.message)?.setTextColor(Color.LTGRAY)
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(blue)
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(blue)
    }
    private fun showIconPicker(target: EditText) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(12), dp(16), dp(12)); setBackgroundColor(cardColor)
        }
        box.addView(TextView(this).apply { text = tr("Icon-Bibliothek auswählen", "Select icon library"); setTextColor(Color.WHITE); textSize = 16f; setTypeface(null, Typeface.BOLD) })
        box.addView(TextView(this).apply { text = tr("Zwischen Classic und F7 wechseln, um unterschiedliche Symbole zu sehen.", "Switch between Classic and F7 to browse different icons."); setTextColor(muted); textSize = 12f })
        val source = Spinner(this)
        val sources = arrayOf(tr("Classic – klassische Icons", "Classic – traditional icons"), tr("F7 – moderne Icons", "F7 – modern icons"))
        source.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, sources) {
            private fun style(view: View): View = view.apply {
                if (this is TextView) { setTextColor(Color.WHITE); textSize = 16f; setPadding(dp(14), dp(12), dp(14), dp(12)) }
                setBackgroundColor(fieldColor)
            }
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getView(position, convertView, parent))
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                style(super.getDropDownView(position, convertView, parent))
        }
        source.background = rounded(fieldColor)
        // Explicit dropdown affordance, without hiding the selected library label.
        source.setPadding(dp(8), 0, dp(28), 0)
        val sourceRow = android.widget.FrameLayout(this).apply { background = rounded(fieldColor) }
        sourceRow.addView(source, android.widget.FrameLayout.LayoutParams(-1, -1))
        val arrow = TextView(this).apply {
            text = "▾"; textSize = 23f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER; isClickable = false; isFocusable = false
        }
        sourceRow.addView(arrow, android.widget.FrameLayout.LayoutParams(dp(40), -1, Gravity.END or Gravity.CENTER_VERTICAL))
        if (target.text.toString().startsWith("f7:")) source.setSelection(1)
        box.addView(sourceRow, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(16) })
        val filter = EditText(this).apply {
            hint = tr("Icon-Namen suchen oder eingeben", "Search or enter icon name")
            setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(muted)
            background = rounded(fieldColor); setPadding(dp(12), dp(10), dp(12), dp(10))
            setText(target.text.toString().removePrefix("f7:"))
        }
        box.addView(filter, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(16) })
        val preview = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(8) } }
        box.addView(TextView(this).apply { text = tr("Aktuell verwendetes Icon", "Currently used icon"); setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD) })
        box.addView(preview)
        val status = TextView(this).apply { setTextColor(muted); gravity = Gravity.CENTER }
        box.addView(status, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        box.addView(TextView(this).apply { text = tr("Verfügbare Icons – zum Auswählen antippen", "Available icons – tap to select"); setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD) })
        val gallery = GridLayout(this).apply { columnCount = 4; alignmentMode = GridLayout.ALIGN_BOUNDS }
        val scroll = ScrollView(this).apply { addView(gallery); layoutParams = LinearLayout.LayoutParams(-1, dp(180)) }
        box.addView(scroll)
        val dialog = AlertDialog.Builder(this)
            .setTitle(tr("Icon auswählen", "Choose icon"))
            .setView(box)
            .setNegativeButton(tr("Abbrechen", "Cancel"), null)
            .setPositiveButton(tr("Übernehmen", "Apply")) { _, _ ->
                val chosen = filter.text.toString().trim()
                if (chosen.isNotEmpty()) target.setText(if (source.selectedItemPosition == 1) "f7:$chosen" else chosen)
            }.create()
        var generation = 0
        val cache = mutableMapOf<String, Bitmap>()
        fun renderSvg(svg: String): Bitmap {
            val picture = SVG.getFromString(svg).renderToPicture(dp(52), dp(52))
            val bitmap = Bitmap.createBitmap(dp(52), dp(52), Bitmap.Config.ARGB_8888)
            Canvas(bitmap).drawPicture(picture)
            return bitmap
        }
        fun showPreview(name: String) {
            val id = ++generation
            preview.setImageDrawable(null)
            if (name.isBlank()) { status.text = ""; return }
            val f7 = source.selectedItemPosition == 1
            status.text = tr("Vorschau wird geladen …", "Loading preview …")
            background {
                try {
                    val svg = if (f7) assets.open("f7/$name.svg").bufferedReader().use { it.readText() }
                    else {
                        val conn = URL(endpoint("items").substringBefore("/rest/") + "/icon/$name.svg").openConnection() as HttpURLConnection
                        try {
                            conn.connectTimeout = 5000; conn.readTimeout = 5000
                            if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
                            conn.inputStream.bufferedReader().use { it.readText() }
                        } finally { conn.disconnect() }
                    }
                    val bitmap = renderSvg(svg)
                    runOnUiThread {
                        if (id == generation && dialog.isShowing) {
                            preview.setImageBitmap(bitmap)
                            if (f7) preview.setColorFilter(Color.WHITE) else preview.clearColorFilter()
                            status.text = if (f7) "F7: $name" else "Classic: $name"
                        }
                    }
                } catch (_: Exception) {
                    runOnUiThread { if (id == generation && dialog.isShowing) status.text = tr("Keine Vorschau verfügbar – Name kann trotzdem übernommen werden", "Preview unavailable – name can still be applied") }
                }
            }
        }
        fun updateList() {
            gallery.removeAllViews()
            val term = filter.text.toString().trim()
            val f7 = source.selectedItemPosition == 1
            val names = if (f7) f7Icons else classicSuggestions
            val width = ((resources.displayMetrics.widthPixels - dp(92)) / 4).coerceAtLeast(dp(55))
            names.asSequence().filter { it.contains(term, ignoreCase = true) }.take(80).forEach { name ->
                val tile = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(3), dp(7), dp(3), dp(7))
                    background = rounded(if (name == term) blue else fieldColor, 9)
                }
                val picture = ImageView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dp(45), dp(45))
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    if (f7) setColorFilter(Color.WHITE)
                }
                tile.addView(picture)
                tile.addView(TextView(this).apply {
                    text = name.replace('_', ' ')
                    textSize = 10f
                    maxLines = 2
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    layoutParams = LinearLayout.LayoutParams(-1, dp(32))
                })
                gallery.addView(tile, GridLayout.LayoutParams().apply {
                    this.width = dp(76); this.height = dp(94)
                    setMargins(dp(5), dp(5), dp(5), dp(5))
                })
                tile.setOnClickListener { filter.setText(name); filter.setSelection(name.length) }
                if (f7) {
                    val bitmap = cache[name]
                    if (bitmap != null) picture.setImageBitmap(bitmap)
                    else background {
                        try {
                            val svg = assets.open("f7/$name.svg").bufferedReader().use { it.readText() }
                            val result = renderSvg(svg)
                            synchronized(cache) { cache[name] = result }
                            runOnUiThread { if (picture.parent === tile) picture.setImageBitmap(result) }
                        } catch (_: Exception) { }
                    }
                } else {
                    background {
                        try {
                            val conn = URL(endpoint("items").substringBefore("/rest/") + "/icon/$name.svg").openConnection() as HttpURLConnection
                            val svg = try {
                                conn.connectTimeout = 5000; conn.readTimeout = 5000
                                if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
                                conn.inputStream.bufferedReader().use { it.readText() }
                            } finally { conn.disconnect() }
                            val result = renderSvg(svg)
                            runOnUiThread { if (picture.parent === tile) picture.setImageBitmap(result) }
                        } catch (_: Exception) { }
                    }
                }
            }
            val count = gallery.childCount
            val rows = ((count + 3) / 4).coerceAtLeast(1)
            scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply {
                height = dp((rows * 104).coerceAtMost(180))
            }
            showPreview(term)
        }
        filter.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateList() }
            override fun afterTextChanged(s: Editable?) {}
        })
        source.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) { updateList() }
        }
        dialog.show(); styleDialog(dialog); updateList()
        // Keep the picker compact while allowing the gallery to scroll.
        val maxHeight = (resources.displayMetrics.heightPixels * 0.75f).toInt()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.window?.decorView?.post {
            val window = dialog.window ?: return@post
            if (window.decorView.height > maxHeight) {
                scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply {
                    height = dp(105)
                }
                scroll.requestLayout()
                window.setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
            }
        }
    }
    private fun redraw() {
        // New tiles default to the next position after all existing tiles.
        // Users can still change the position manually in the tile dialog.
        position.setText((pending.length() + 1).toString())
        entries.removeAllViews()
        for (i in 0 until pending.length()) {
            val w = pending.getJSONObject(i)
            entries.addView(Button(this).apply {
                gravity = Gravity.CENTER
                textAlignment = View.TEXT_ALIGNMENT_CENTER
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = rounded(cardColor)
                text = "${i + 1}. ${w.optString("label", w.optString("item"))}"
                setOnClickListener {
                    val item = JSONObject().put("name", w.optString("item")).put("label", w.optString("label"))
                    showTileDialog(item, i)
                }
                setOnLongClickListener {
                    val next = JSONArray()
                    for (j in 0 until pending.length()) if (j != i) next.put(pending.getJSONObject(j))
                    pending = next
                    redraw()
                    true
                }
            })
        }
    }
    private fun escapeSitemap(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ")

    // Export only constructs supported by the editor. Never silently discard unknown widget semantics.
    private fun sitemapText(name: String): String {
        val lines = mutableListOf<String>()
        lines.add("sitemap $name label=\"${escapeSitemap(name)}\" {")
        lines.add("    Frame {")
        for (i in 0 until pending.length()) {
            val w = pending.getJSONObject(i)
            val type = w.optString("type")
            require(type in setOf("Text", "Switch", "Slider")) { "Unsupported widget type: $type" }
            val item = w.optString("item")
            require(item.matches(Regex("[A-Za-z0-9_]+"))) { "Invalid item: $item" }
            val label = escapeSitemap(w.optString("label", item))
            val icon = w.optString("icon")
            require(icon.isEmpty() || icon.matches(Regex("[A-Za-z0-9_:-]+"))) { "Invalid icon: $icon" }
            val allowed = setOf("type", "item", "label", "icon", "mappings", "link", "widgetId", "id")
            val keys = w.keys().asSequence().toSet()
            val unsupported = keys - allowed
            require(unsupported.isEmpty()) { "Widget ${i + 1} has unsupported fields: $unsupported" }
            val line = StringBuilder("        $type item=$item label=\"$label\"")
            if (icon.isNotEmpty()) line.append(" icon=\"${escapeSitemap(icon)}\"")
            val mappings = w.optJSONArray("mappings")
            if (mappings != null && mappings.length() > 0) {
                require(type == "Switch") { "Mappings require a Switch widget" }
                val parts = (0 until mappings.length()).map { index ->
                    val mapping = mappings.getJSONObject(index)
                    val command = mapping.optString("command")
                    require(command.matches(Regex("[A-Za-z0-9_.-]+"))) { "Invalid mapping command" }
                    "$command=\"${escapeSitemap(mapping.optString("label"))}\""
                }
                line.append(" mappings=[${parts.joinToString(",") }]")
            }
            lines.add(line.toString())
        }
        lines.add("    }")
        lines.add("}")
        return lines.joinToString("\n", postfix = "\n")
    }

    private fun exportSitemap() {
        if (definition == null) { message(tr("Zuerst Sitemap laden", "Load sitemap first")); return }
        val suggested = (loadedSite.ifBlank { site() }).removeSuffix(".sitemap").trim()
        val field = EditText(this).apply {
            setSingleLine(true); setText(suggested); selectAll()
            setTextColor(Color.WHITE); setBackgroundColor(fieldColor)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        AlertDialog.Builder(this)
            .setTitle(tr("Sitemap exportieren", "Export sitemap"))
            .setMessage(tr("Dateiname bearbeiten. Die Datei wird in Downloads gespeichert. OH Weather wechselt dabei nicht automatisch die aktive Sitemap.", "Edit the filename. The file will be saved in Downloads. The active sitemap will not change."))
            .setView(field)
            .setNegativeButton(tr("Abbrechen", "Cancel"), null)
            .setPositiveButton(tr("Exportieren", "Export")) { _, _ ->
                val name = field.text.toString().removeSuffix(".sitemap").trim()
                if (!name.matches(Regex("[A-Za-z][A-Za-z0-9_]*"))) {
                    message(tr("Ungültiger Name: nur Buchstaben, Zahlen und _", "Invalid name: use letters, digits and _"))
                    return@setPositiveButton
                }
                try {
                    val contents = sitemapText(name)
                    val filename = "$name.sitemap"
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, filename)
                        put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: error("Cannot create Downloads file")
                    try {
                        contentResolver.openOutputStream(uri)?.use { it.write(contents.toByteArray(Charsets.UTF_8)) }
                            ?: error("Cannot write Downloads file")
                        contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                        message(tr("Exportiert: Downloads/$filename. Auf den openHAB-Server kopieren; aktive Sitemap bleibt $loadedSite.", "Exported: Downloads/$filename. Copy to openHAB server; active sitemap remains $loadedSite."))
                    } catch (e: Exception) {
                        contentResolver.delete(uri, null, null)
                        throw e
                    }
                } catch (e: Exception) {
                    message(tr("Export nicht möglich: ${e.message}", "Export failed: ${e.message}"))
                }
            }.show().also { styleDialog(it) }
    }

    private fun saveNotice(title: String, detail: String) {
        runOnUiThread {
            if (!isFinishing && !isDestroyed) {
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(detail)
                    .setPositiveButton("OK", null)
                    .show().also { styleDialog(it) }
            }
        }
    }

    private fun save() {
        // A visible dialog confirms that the button click was received.
        val current = loadedSite.ifBlank { site() }
        AlertDialog.Builder(this)
            .setTitle(tr("REST-Speicherung", "REST save"))
            .setMessage(tr("Quelle: $current\nZiel: ohweather_live (REST)\n\nDie Datei unter /etc/openhab/sitemaps/ wird NICHT geändert. Eine vorhandene REST-Sitemap ohweather_live wird ersetzt. Die aktive Sitemap bleibt unverändert. Fortfahren?", "Source: $current\nDestination: ohweather_live (REST)\n\nThe file in /etc/openhab/sitemaps/ will NOT change. An existing REST sitemap ohweather_live will be replaced. The active sitemap remains unchanged. Continue?"))
            .setNegativeButton(tr("Abbrechen", "Cancel"), null)
            .setPositiveButton(tr("Speichern", "Save")) { _, _ -> performRestSave() }
            .show().also { styleDialog(it) }
    }

    private fun performRestSave() {
        val original = definition ?: run { message(tr("Keine bearbeitbare Sitemap geladen", "No editable sitemap loaded")); return }
        if (loadedSite != site()) { message(tr("Sitemap in Einstellungen geändert; bitte neu laden", "Sitemap changed in settings; reload first")); return }
        
        val fileBased = sourceFileBased
        val data = JSONObject(original.toString()).apply {
            remove("editable")
            put("widgets", JSONArray(pending.toString()))
        }
        message(tr("REST-Speicherung läuft …", "REST save in progress …"))
        background {
            // Prevent overwriting changes made elsewhere since loading.
            val (checkCode, checkBody) = request("sitemaps/$loadedSite/definition")
            if (checkCode != 200 || JSONObject(checkBody).optJSONArray("widgets")?.toString() != original.optJSONArray("widgets")?.toString()) {
                message(tr("Sitemap wurde auf dem Server geändert. Vor dem Speichern neu laden.", "Sitemap changed on server. Reload before saving."))
                return@background
            }
            // One stable REST destination. Never auto-switch the active sitemap.
            val destination = "ohweather_live"
            if (loadedSite == destination && fileBased) {
                saveNotice(tr("Speichern abgebrochen", "Save cancelled"), tr("Die Quelle ist nicht eindeutig. Bitte Sitemap neu laden.", "Source is ambiguous. Please reload the sitemap."))
                return@background
            }
            data.put("name", destination)
            data.put("label", "OH Weather Live")
            val (code, _) = request("sitemaps/$destination", "PUT", data.toString())
            if (code !in 200..299) {
                saveNotice(tr("REST-Fehler", "REST error"), tr("HTTP $code: Speichern nicht möglich.", "HTTP $code: Could not save."))
                return@background
            }
            val (verifyCode, verifyBody) = request("sitemaps/$destination/definition")
            if (verifyCode != 200 || JSONObject(verifyBody).optJSONArray("widgets")?.toString() != pending.toString()) {
                saveNotice(tr("Prüfung fehlgeschlagen", "Verification failed"), tr("HTTP $code, aber Serverinhalt weicht ab.", "HTTP $code, but server content differs."))
            } else {
                // Offer an explicit choice only after the server returned the saved sitemap.
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        val active = site()
                        AlertDialog.Builder(this)
                            .setTitle(tr("REST-Sitemap gespeichert", "REST sitemap saved"))
                            .setMessage(tr(
                                "Die Sitemap wurde als ohweather_live in openHAB gespeichert und geprüft.\n\nAktuell verwendet OH Weather: $active\n\nDie ursprüngliche .sitemap-Datei wurde nicht geändert.\n\nMöchtest du jetzt ohweather_live in OH Weather und Android Auto verwenden?",
                                "The sitemap was saved and verified as ohweather_live in openHAB.\n\nCurrently used by OH Weather: $active\n\nThe original .sitemap file was not changed.\n\nDo you want OH Weather and Android Auto to use ohweather_live now?"
                            ))
                            .setPositiveButton(tr("Jetzt umschalten", "Switch now")) { _, _ ->
                                if (prefs.edit().putString("sitemap", destination).commit()) {
                                    loadedSite = destination
                                    sourceFileBased = false
                                    definition = JSONObject(data.toString())
                                    message(tr("Aktive Sitemap: ohweather_live (REST). Zurück in den Einstellungen wird dieser Name angezeigt.", "Active sitemap: ohweather_live (REST). This name appears in Settings when you return."))
                                } else {
                                    saveNotice(tr("Umschalten fehlgeschlagen", "Switch failed"), tr("Sitemap wurde gespeichert, aber die Auswahl konnte nicht übernommen werden.", "Sitemap was saved, but the selection could not be updated."))
                                }
                            }
                            .setNegativeButton(tr("Bisherige behalten", "Keep current")) { _, _ ->
                                message(tr("REST-Sitemap ohweather_live gespeichert. Aktive Sitemap bleibt $active.", "REST sitemap ohweather_live saved. Active sitemap remains $active."))
                            }
                            .show().also { styleDialog(it) }
                    }
                }
            }
        }
    }
}



