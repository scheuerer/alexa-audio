package de.ohweather.app

import android.content.Intent
import android.content.pm.ApplicationInfo
import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.Screen
import androidx.car.app.CarContext
import androidx.car.app.AppManager
import androidx.car.app.SurfaceCallback
import androidx.car.app.SurfaceContainer
import androidx.car.app.model.*
import androidx.car.app.navigation.model.MapWithContentTemplate
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import org.json.JSONObject
import java.net.URLEncoder
import android.util.Log
import android.view.Surface

class WeatherCarService : CarAppService() {
    override fun createHostValidator() = androidx.car.app.validation.HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = object : Session() {
        override fun onCreateScreen(intent: Intent): Screen = WeatherScreen(carContext)
    }
}

private class WeatherScreen(ctx: CarContext) : Screen(ctx), DefaultLifecycleObserver {
    private val renderer = WeatherMapRenderer()
    @Volatile private var live = false
    @Volatile private var temp = "–"
    @Volatile private var wind = "–"
    @Volatile private var direction = "–"
    @Volatile private var rain = "–"
    @Volatile private var rainStatus = "–"
    @Volatile private var pressure = "–"
    @Volatile private var humidity = "–"
    @Volatile private var lastError = "Warte auf openHAB"
    @Volatile private var updatedAt = "–"
    private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var lastHistoryFetch = 0L
    @Volatile private var chartIndex = 0
    private fun favorites() = WeatherConfig.favorites(carContext)
    private val favoriteValues = java.util.concurrent.ConcurrentHashMap<String,String>()
    @Volatile private var running = true

    init { lifecycle.addObserver(this) }

    private fun format(raw: String, unit: String): String {
        val value = raw.trim().replace('.', ',')
        return if (value.contains(Regex("[a-zA-Z°%]"))) value else "$value $unit"
    }
    private fun directionName(raw: String): String = when(raw.trim().uppercase()) {
        "N" -> "Nord"; "NNO", "NNE" -> "Nord-Nordost"; "NO", "NE" -> "Nordost"
        "ONO", "ENE" -> "Ost-Nordost"; "O", "E" -> "Ost"
        "OSO", "ESE" -> "Ost-Südost"; "SO", "SE" -> "Südost"
        "SSO", "SSE" -> "Süd-Südost"; "S" -> "Süd"
        "SSW" -> "Süd-Südwest"; "SW" -> "Südwest"; "WSW" -> "West-Südwest"
        "W" -> "West"; "WNW" -> "West-Nordwest"; "NW" -> "Nordwest"
        "NNW" -> "Nord-Nordwest"; else -> raw
    }
    private fun refresh() {
        // Read every field independently: one missing Item must not hide all live values.
        val values = mutableMapOf<String, String>()
        var successful = 0
        val failures = mutableListOf<String>()
        for (key in listOf("Temperatur", "Wind", "Windrichtung", "Regenstatus", "Regenmenge", "Luftfeuchtigkeit", "Luftdruck")) {
            try {
                val v = WeatherConfig.state(carContext, key)
                if (v.isNotBlank() && v != "–" && v != "NULL" && v != "UNDEF") {
                    values[key] = v; successful++
                }
            } catch (e: Exception) {
                failures.add("$key: ${e.message ?: e.javaClass.simpleName}")
                Log.w("OHWeather", "Item $key nicht erreichbar: ${e.message}")
            }
        }
        live = successful > 0
        temp = values["Temperatur"]?.let { format(it,"°C") } ?: "–"
        wind = values["Wind"]?.let { format(it,"km/h") } ?: "–"
        direction = values["Windrichtung"]?.let { directionName(it) } ?: "–"
        rain = values["Regenmenge"]?.let { format(it,"l/m²") } ?: "–"
        humidity = values["Luftfeuchtigkeit"]?.let { format(it,"%") } ?: "–"
        pressure = values["Luftdruck"]?.let { format(it,"hPa") } ?: "–"
        rainStatus = when(values["Regenstatus"]?.uppercase()) {
            "ON" -> "Regen erkannt"
            "OFF" -> "Kein Regen"
            else -> values["Regenstatus"] ?: "–"
        }
        lastError = if (live) "openHAB Live ($successful/6)" else
            (failures.firstOrNull()?.take(85) ?: "Keine gültigen Item-Zustände")
        if (live) updatedAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.GERMANY).format(java.util.Date())
        for (fav in favorites()) {
            try { favoriteValues[fav.item] = WeatherConfig.itemState(carContext,fav.item) } catch (_:Exception) { favoriteValues[fav.item] = "–" }
        }
        renderer.setSpecs(favorites())
        renderer.update(temp, wind, rain, rainStatus, live)
        if (System.currentTimeMillis() - lastHistoryFetch > 300_000L) {
            lastHistoryFetch = System.currentTimeMillis()
            for (fav in favorites()) {
                val kind = fav.label
                try {
                    val item = fav.item
                    val start = System.currentTimeMillis() - 24L * 60 * 60 * 1000
                    val path = "/rest/persistence/items/${URLEncoder.encode(item, "UTF-8")}?serviceId=rrd4j&starttime=$start"
                    val data = JSONObject(WeatherConfig.request(carContext, path)).optJSONArray("data")
                    val points = mutableListOf<Pair<Long, Float>>()
                    if (data != null) for (i in 0 until data.length()) {
                        val row = data.optJSONObject(i) ?: continue
                        val timestamp = row.optLong("time", 0)
                        val raw = row.optString("state").trim().uppercase()
                        val value = if (fav.type == "state") when(raw) {"ON","OPEN","TRUE","1" -> 1f;"OFF","CLOSED","FALSE","0" -> 0f;else -> null} else raw.substringBefore(' ').toFloatOrNull()
                        if (timestamp > 0 && value != null && value.isFinite()) points.add(timestamp to value)
                    }
                    renderer.setHistory(kind, points)
                } catch (e: Exception) {
                    renderer.setHistory(kind, emptyList())
                    Log.w("OHWeather", "$kind Verlauf nicht erreichbar: ${e.message}")
                }
            }
        }
        carContext.mainExecutor.execute { if (running) invalidate() }
    }

    override fun onCreate(owner: LifecycleOwner) {
        try {
            WeatherConfig.migrate(carContext)
            carContext.getCarService(AppManager::class.java).setSurfaceCallback(renderer)
            worker.execute {
                while (running && !Thread.currentThread().isInterrupted) {
                    try { refresh() } catch (e: Exception) {
                        live = false; lastError = "Verbindungsfehler: ${e.message ?: e.javaClass.simpleName}"
                        Log.w("OHWeather", "Wetteraktualisierung fehlgeschlagen", e)
                    }
                    try { Thread.sleep(30_000) } catch (_: InterruptedException) { break }
                }
            }
        } catch (e: Exception) {
            Log.e("OHWeather", "SurfaceCallback registration failed", e)
        }
    }

    override fun onDestroy(owner: LifecycleOwner) {
        running = false
        worker.shutdownNow()
        try { carContext.getCarService(AppManager::class.java).setSurfaceCallback(null) }
        catch (e: Exception) { Log.w("OHWeather", "Could not clear surface callback", e) }
    }

    override fun onGetTemplate(): Template {
        val listBuilder = ItemList.Builder()
        val entries = favorites().map { fav ->
            val raw = favoriteValues[fav.item] ?: "–"
            val shown = if (fav.type=="state") when(raw.trim().uppercase()) {"ON","OPEN","TRUE","1" -> "AN";"OFF","CLOSED","FALSE","0" -> "AUS";else -> raw} else format(raw,fav.unit)
            fav.label to shown
        }
        entries.forEachIndexed { index, entry ->
            val active = chartIndex == index
            listBuilder.addItem(Row.Builder()
                .setTitle((if (active) "● " else "") + entry.first + "  ·  " + entry.second)
                .setOnClickListener {
                    chartIndex = index
                    renderer.selectChart(entries[index].first)
                    invalidate()
                }.build())
        }
        val itemList = listBuilder.build()
        val content = ListTemplate.Builder()
            .setSingleList(itemList)
            .setHeaderAction(Action.APP_ICON)
            .setTitle("OH Weather · v${BuildConfig.VERSION_NAME}")
            .build()
        return MapWithContentTemplate.Builder()
            .setContentTemplate(content)
            .build()
    }

}

/** Schematic weather map for display/API testing. NOT a geographical basemap. */
private class WeatherMapRenderer : SurfaceCallback {
    private var surface: Surface? = null
    private var width = 0
    private var height = 0
    private var stable: Rect? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    @Volatile private var currentTemp="–"
    @Volatile private var currentWind="–"
    @Volatile private var currentRain="–"
    @Volatile private var currentStatus="Warte auf openHAB"
    @Volatile private var isLive=false
    @Volatile private var selectedChart = "Temperatur"
    private val histories = java.util.concurrent.ConcurrentHashMap<String, List<Pair<Long, Float>>>()
    @Volatile private var favoriteSpecs = WeatherConfig.initialFavorites
    fun setSpecs(specs:List<WeatherConfig.Favorite>) { favoriteSpecs=specs }
    fun setHistory(kind: String, points: List<Pair<Long, Float>>) {
        histories[kind] = points.sortedBy { it.first }
        if (kind == selectedChart) drawMap()
    }
    fun selectChart(kind: String) { selectedChart = kind; drawMap() }
    fun update(t:String,w:String,r:String,status:String,live:Boolean) {
        currentTemp=t;currentWind=w;currentRain=r;currentStatus=status;isLive=live;drawMap()
    }

    override fun onSurfaceAvailable(container: SurfaceContainer) {
        release()
        surface = container.surface
        width = container.width
        height = container.height
        drawMap()
    }

    override fun onSurfaceDestroyed(container: SurfaceContainer) { release() }

    override fun onStableAreaChanged(stableArea: Rect) {
        stable = Rect(stableArea)
        drawMap()
    }

    override fun onVisibleAreaChanged(visibleArea: Rect) { drawMap() }

    private fun release() {
        try { surface?.release() } catch (_: Exception) { }
        surface = null
    }

    private fun niceStep(spread: Float): Float {
        val raw = (spread / 4f).coerceAtLeast(0.01f)
        val power = Math.pow(10.0, kotlin.math.floor(kotlin.math.log10(raw.toDouble()))) .toFloat()
        val normalized = raw / power
        return (when { normalized <= 1f -> 1f; normalized <= 2f -> 2f; normalized <= 5f -> 5f; else -> 10f }) * power
    }

    private fun drawMap() {
        val s = surface ?: return
        if (!s.isValid || width <= 0 || height <= 0) return
        var canvas: Canvas? = null
        try {
            canvas = s.lockCanvas(null)
            val w = canvas.width.toFloat()
            val h = canvas.height.toFloat()
            canvas.drawColor(Color.rgb(21, 40, 52))

            // Experimental surface graph: host-controlled pane may cover the left area.
            val left = w * 0.53f + 45f
            val right = w - 28f
            val top = h * 0.18f
            val bottom = h * 0.82f
            if (right <= left + 60f) return
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(230, 240, 246)
            paint.textSize = (h * 0.036f).coerceIn(18f, 32f)
            val kind = selectedChart
            val spec = favoriteSpecs.firstOrNull { it.label==kind }
            val unit = spec?.unit ?: ""
            val chartType = spec?.type ?: "line"
            canvas.drawText("$kind · 24 Stunden", left, top - 25f, paint)
            val pts = histories[kind] ?: emptyList()
            if (pts.size < 2) {
                paint.textSize = (h * 0.026f).coerceIn(15f, 24f)
                canvas.drawText("Keine Verlaufsdaten aus RRD4J", left, top + 45f, paint)
            } else {
                val lo = pts.minOf { it.second }
                val hi = pts.maxOf { it.second }
                val spread = (hi - lo).coerceAtLeast(0.5f)
                val minV = if (chartType == "state" || chartType == "bar" || unit == "km/h" || unit == "l/m²") 0f else kotlin.math.floor(((lo - spread * 0.12f) / niceStep(spread)).toDouble()).toFloat() * niceStep(spread)
                val maxV = if (chartType == "state") 1f else (kotlin.math.ceil(((hi + spread * 0.12f) / niceStep(spread)).toDouble()).toFloat() * niceStep(spread)).coerceAtLeast(minV + 0.5f)
                val t0 = pts.first().first
                val t1 = pts.last().first.coerceAtLeast(t0 + 1)
                paint.color = Color.rgb(75, 104, 118)
                paint.strokeWidth = 1.5f
                for (i in 0..4) {
                    val y = top + (bottom-top)*i/4f
                    canvas.drawLine(left, y, right, y, paint)
                    paint.color = Color.WHITE
                    paint.style = Paint.Style.FILL
                    paint.textSize = (h * 0.020f).coerceIn(12f, 19f)
                    val tick = maxV - (maxV-minV)*i/4f
                    val tickText = if(chartType=="state") when(i) {0 -> "AN";4 -> "AUS";else -> ""} else String.format(java.util.Locale.GERMANY, "%.1f", tick)
                    canvas.drawText(tickText, left - 42f, y + 5f, paint)
                    paint.color = Color.rgb(75, 104, 118)
                }
                val curve = Path()
                if (chartType == "bar" || chartType == "state") {
                    paint.color = Color.rgb(88, 198, 250)
                    paint.style = Paint.Style.FILL
                    val barWidth = if(chartType=="state") ((right-left) / pts.size.coerceAtLeast(1)).coerceAtLeast(2f) else ((right-left) / pts.size.coerceAtLeast(1)).coerceIn(2f, 14f)
                    pts.forEach { point ->
                        val x = left + (point.first-t0).toFloat()/(t1-t0).toFloat()*(right-left)
                        val y = bottom - (point.second.coerceAtLeast(0f)-minV)/(maxV-minV)*(bottom-top)
                        if(chartType=="state") { if(point.second>=0.5f) canvas.drawRect(x, top+(bottom-top)*0.12f, (x+barWidth+1f).coerceAtMost(right), bottom-(bottom-top)*0.12f, paint) } else canvas.drawRect(x, y, (x+barWidth).coerceAtMost(right), bottom, paint)
                    }
                } else {
                    pts.forEachIndexed { index, point ->
                        val x = left + (point.first-t0).toFloat()/(t1-t0).toFloat()*(right-left)
                        val y = bottom - (point.second-minV)/(maxV-minV)*(bottom-top)
                        if (index == 0) curve.moveTo(x,y) else curve.lineTo(x,y)
                    }
                    paint.color = Color.rgb(88, 198, 250)
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 3.5f
                    canvas.drawPath(curve, paint)
                }
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                paint.textSize = (h * 0.024f).coerceIn(14f, 22f)
                // Axis ticks are rendered beside the grid lines.
                
                val clock = java.text.SimpleDateFormat("dd.MM. HH:mm", java.util.Locale.GERMANY)
                canvas.drawText(clock.format(java.util.Date(t0)), left, bottom + 32f, paint)
                // No ambiguous midpoint label on compact Android Auto surfaces.
                val endLabel=clock.format(java.util.Date(t1))
                canvas.drawText(endLabel, right-paint.measureText(endLabel), bottom + 32f, paint)
            }
        } catch (e: Exception) {
            Log.e("OHWeather", "Surface drawing failed", e)
        } finally {
            if (canvas != null) try { s.unlockCanvasAndPost(canvas) } catch (_: Exception) { }
        }
    }
}
