package de.ohweather.app

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object WeatherConfig {
    val defaults = linkedMapOf(
        "Temperatur" to "Wetter_Aussen_Outdoor_Station_Sensordaten_Innentemperatur",
        "Luftfeuchtigkeit" to "Wetter_Aussen_Outdoor_Station_Luftfeuchtigkeit",
        "Wind" to "Wetter_Aussen_Outdoor_Station_Wind_Speed",
        "Windrichtung" to "Wetter_Aussen_Outdoor_Station_Wind_Direction_Compass",
        "Boeen" to "Wetter_Aussen_Outdoor_Station_Gust_Speed",
        "Regenstatus" to "Wetter_Aussen_Outdoor_Station_Rain_Status_Verifiziert",
        "Regenmenge" to "Wetter_Aussen_Outdoor_Station_Regen_Verifiziert_1h",
        "Regen24h" to "Wetter_Aussen_Outdoor_Station_Regen_Verifiziert_24h",
        "Luftdruck" to "Wetter_Aussen_Outdoor_Station_Atmospheric_Pressure_corrected"
    )
    // Older 0.3 installations saved placeholder names. Migrate only unchanged placeholders.
    private val obsolete = mapOf(
        "Temperatur" to "Gartentemperatur", "Luftfeuchtigkeit" to "Luftfeuchtigkeit",
        "Wind" to "Windgeschwindigkeit", "Regenmenge" to "Regen_1h",
        "Luftdruck" to "Luftdruck"
    )
    fun migrate(c: Context) {
        val prefs = prefs(c)
        val edit = prefs.edit()
        var changed = false
        for ((label, old) in obsolete) {
            val key = "item_$label"
            if (prefs.getString(key, null) == old) {
                edit.putString(key, defaults[label]); changed = true
            }
        }
        // Old "Regen" field contained an ON/OFF item, not precipitation in mm.
        val oldRain = prefs.getString("item_Regen", null)
        if (oldRain != null && !prefs.contains("item_Regenstatus")) {
            edit.putString("item_Regenstatus", if (oldRain == "Rain_Status_Verifiziert") defaults.getValue("Regenstatus") else oldRain)
            changed = true
        }
        // Also repair legacy fully-qualified placeholders if saved by an older build.
        val legacy = mapOf(
            "Regenstatus" to "Wetter_Aussen_Outdoor_Station_Rain_Status_Verifiziert",
            "Regenmenge" to "Wetter_Aussen_Outdoor_Station_Regen_Verifiziert_1h"
        )
        for ((label, target) in legacy) {
            val key = "item_$label"
            if (prefs.getString(key, null) in listOf("Rain_Status_Verifiziert", "Regen_1h")) {
                edit.putString(key, target); changed = true
            }
        }
        if (changed) edit.commit()
    }

    data class Favorite(val label:String, val item:String, val type:String, val unit:String)
    val initialFavorites = listOf(
        Favorite("Temperatur", defaults.getValue("Temperatur"), "line", "°C"),
        Favorite("Luftfeuchtigkeit", defaults.getValue("Luftfeuchtigkeit"), "line", "%"),
        Favorite("Wind", defaults.getValue("Wind"), "line", "km/h"),
        Favorite("Regenmenge", defaults.getValue("Regenmenge"), "bar", "l/m²"),
        Favorite("Luftdruck", defaults.getValue("Luftdruck"), "line", "hPa")
    )
    fun favorites(c: Context): List<Favorite> {
        val raw = get(c,"favorites_v1")
        if(raw.isBlank()) return initialFavorites.map { it.copy(item=item(c,it.label)) }
        return try {
            val arr=JSONArray(raw)
            if(arr.length() !in 1..6) initialFavorites else (0 until arr.length()).map { i ->
                val o=arr.getJSONObject(i)
                Favorite(o.optString("label","Favorit ${i+1}"),o.optString("item"),o.optString("type","line"),o.optString("unit"))
            }
        } catch (_:Exception) { initialFavorites }
    }
    fun saveFavorites(c:Context, list:List<Favorite>) {
        require(list.size in 1..6)
        val arr=JSONArray()
        list.forEach { f -> arr.put(JSONObject().put("label",f.label).put("item",f.item).put("type",f.type).put("unit",f.unit)) }
        prefs(c).edit().putString("favorites_v1",arr.toString()).apply()
    }
    fun itemState(c:Context, name:String):String {
        val json=JSONObject(request(c,"/rest/items/${java.net.URLEncoder.encode(name,"UTF-8")}"))
        return json.optString("state","–")
    }
    fun prefs(c: Context) = c.getSharedPreferences("ohweather", Context.MODE_PRIVATE)
    fun get(c: Context, key: String, default: String = "") = prefs(c).getString(key, default) ?: default
    fun base(c: Context): String {
        val mode = get(c,"mode","local")
        val host = get(c,if(mode=="cloud") "cloud" else "host",if(mode=="cloud") "https://myopenhab.org" else "http://192.168.1.9")
        val port = get(c,"port", "8080")
        val url = if(host.startsWith("http")) host else "http://$host"
        val u = URL(url)
        val portPart = if(mode=="local" && u.port == -1 && port.isNotBlank()) ":$port" else ""
        return ("${u.protocol}://${u.host}" + (if(u.port != -1) ":${u.port}" else portPart) + u.path).trimEnd('/')
    }
    fun authorize(c: Context, conn: HttpURLConnection) {
        val authMode=get(c,"auth_mode", "token")
        val token=WeatherTokenStore.read(c).ifBlank { get(c,"api_token").trim() }
        val user=if(authMode=="token" && token.isNotBlank()) token else if(authMode=="password") get(c,"user") else ""
        val secret=if(authMode=="password") get(c,"secret") else ""
        if(user.isNotBlank() || secret.isNotBlank()) {
            val token=Base64.encodeToString("$user:$secret".toByteArray(Charsets.UTF_8),Base64.NO_WRAP)
            conn.setRequestProperty("Authorization","Basic $token")
        }
    }
    fun request(c: Context, path: String): String {
        val conn = (URL(base(c)+path).openConnection() as HttpURLConnection)
        conn.connectTimeout=6500; conn.readTimeout=6500
        conn.setRequestProperty("Accept","application/json")
        authorize(c, conn)
        try { if(conn.responseCode !in 200..299) throw Exception("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally { conn.disconnect() }
    }
    fun item(c: Context, label: String): String = get(c,"item_$label",defaults[label]?:"")
    fun state(c: Context, label: String): String {
        val name=item(c,label)
        if(name.isBlank()) return "–"
        // Use the JSON item endpoint: /state returns plain text, which is not reliably
        // compatible with the JSON Accept header used by request().
        val json = JSONObject(request(c,"/rest/items/${java.net.URLEncoder.encode(name,"UTF-8")}"))
        return json.optString("state", "–")
    }
    fun sitemapNames(c: Context): List<String> {
        val a=JSONArray(request(c,"/rest/sitemaps"))
        return (0 until a.length()).mapNotNull { a.optJSONObject(it)?.optString("name") }.filter { it.isNotBlank() }
    }
    fun itemNames(c: Context, term: String): List<String> {
        val a=JSONArray(request(c,"/rest/items?recursive=false"))
        val names=(0 until a.length()).mapNotNull { a.optJSONObject(it)?.optString("name") }
        return names.filter { it.contains(term,true) }.take(100)
    }
}
