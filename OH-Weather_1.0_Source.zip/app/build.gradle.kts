plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "de.ohweather.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "de.ohweather.app"
        minSdk = 29
        targetSdk = 35
        versionCode = 22
        versionName = "1.0"
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.car.app:app:1.7.0"); implementation("com.caverock:androidsvg:1.4") }
