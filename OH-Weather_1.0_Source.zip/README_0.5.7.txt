OH Weather 0.5.7 - Source / Teststand

Neu:
- Fuenf frei waehlbare Favoriten, Sortierung im Einstellungsbildschirm
- Volltextsuche nach openHAB Items
- Diagrammtypen Linie, Balken, ON/OFF-Zustand
- Zeitachse mit Datum und Uhrzeit
- Wind- und Regen-Skalen ab null
- Lokal/VPN und Cloud-Einstellungen getrennt sichtbar
- Bestehende API-Token und Item-Konfiguration werden weiterverwendet

WICHTIG: Das Paket wurde hier nicht mit Android Gradle kompiliert oder auf
Android Auto getestet. Bitte Buildfehler vor Installation melden.

Die Favoriten werden vorerst lokal in den App-Einstellungen gespeichert.
Der vorhandene Sitemap-Editor ist unveraendert; eine REST-Synchronisierung
der Favoriten ist in dieser Version noch NICHT implementiert.

Das Quellcodearchiv enthaelt keinen Gradle Wrapper. Fuer den lokalen Build
gradlew.bat und den Ordner gradle aus der bestehenden 0.5.6 Installation
in das neue Projekt kopieren.
