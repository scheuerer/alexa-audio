OH Weather 0.5.8 - Quellcode

- Favoriten frei von 1 bis 6 (lokal gespeichert); vorhandene 5 werden übernommen.
- Sitemap-Einstellungen vor den Favoriten.
- Sitemap-Editor mit REST-Speicherung und Download-Export unverändert erhalten.
- Dunkles Dropdown: weiße Beschriftung.
- Android Auto und RRD4J unverändert.

Hinweis: Die ursprüngliche 0.5.7-Quelldatei enthält keinen Gradle-Wrapper.
Für den Windows-Build den Wrapper aus der bisherigen funktionierenden OH-Weather-Projektumgebung übernehmen.

PowerShell (nach Entpacken nach C:\OH-Weather_0.5.8):
Set-Location "C:\OH-Weather_0.5.8"
.\gradlew.bat assembleDebug
Copy-Item ".\app\build\outputs\apk\debug\app-debug.apk" ".\OH-Weather_0.5.8.apk" -Force
$adb = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
& $adb install -r ".\OH-Weather_0.5.8.apk"
& $adb push ".\OH-Weather_0.5.8.apk" "/sdcard/Download/OH-Weather_0.5.8.apk"
