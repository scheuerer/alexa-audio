OH Weather 0.5.11
Basis: 0.5.10
Sechs frei waehlbare Favoriten bleiben unveraendert.
Keine funktionalen Aenderungen an Diagrammen oder Einstellungen.
