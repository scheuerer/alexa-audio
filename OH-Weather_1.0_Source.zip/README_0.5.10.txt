OH Weather 0.5.10
- Adaptive launcher icon for Android 8+ / Android Auto with blue background; existing weather artwork retained.
- Legacy PNG launcher icons remain unchanged.
- Connection and charts unchanged.
