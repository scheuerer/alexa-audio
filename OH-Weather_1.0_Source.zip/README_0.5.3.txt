OH Weather 0.5.3
- Live REST polling unchanged (30 seconds)
- Removed duplicated weather drawing behind host pane and footer
- German compass names for 16 directions
- Last successful read timestamp
- Blue circular launcher icon
- Removed hardcoded Pfuhl from car surface; automatic openHAB location resolution not yet implemented
- History charts deferred pending template compatibility testing
